class Car:
    def __init__(self, make, model, year, rental_price, available=True):
        self.make = make
        self.model = model
        self.year = year
        self.rental_price = rental_price
        self.available = available

    def rent(self):
        if self.available:
            self.available = False
            return "Car was rented successfully."
        else:
            return "Car is not available for rent."

    def return_car(self):
        if not self.available:
            self.available = True
            return "Car was returned successfully."
        else:
            return "Car has not been rented."

    def __str__(self):
        availability = "Available" if self.available else "Not Available"
        return f"{self.year} {self.make} {self.model} - ugx{self.rental_price} per day - {availability}"


class CarRentalSystem:
    def __init__(self):
        self.cars = []

    def add_car(self, car):
        self.cars.append(car)

    def find_available_cars(self):
        return [car for car in self.cars if car.available]

    def rent_car(self, make, model, year):
        for car in self.cars:
            if car.make == make and car.model == model and car.year == year:
                return car.rent()
        return "Car not found."

    def return_car(self, make, model, year):
        for car in self.cars:
            if car.make == make and car.model == model and car.year == year:
                return car.return_car()
        return "Car not found."

    def display_available_cars(self):
        available_cars = self.find_available_cars()
        if available_cars:
            for car in available_cars:
                print(car)
        else:
            print("No cars available for rent.")

# Example usage:
car1 = Car("Mercedes", "C-class", 2020, 150000)
car2 = Car("Ford", "Ranger", 2021, 100000)
car3 = Car("Kia", "Fentil", 2019, 120000)

car_rental_system = CarRentalSystem()
car_rental_system.add_car(car1)
car_rental_system.add_car(car2)
car_rental_system.add_car(car3)

car_rental_system.display_available_cars()

print(car_rental_system.rent_car("Mercedes", "C-class", 2020))
car_rental_system.display_available_cars()

print(car_rental_system.return_car("Mercedes", "C-class", 2020))
car_rental_system.display_available_cars()
